<?php
return [
	'site_name' => 'Home Appliances',
];