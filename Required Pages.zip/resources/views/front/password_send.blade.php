Welcome {{$name}}<br/>
Your password {{$password}}