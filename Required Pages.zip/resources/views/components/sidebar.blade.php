<div>
    <h3>This is component of {{$name}} have age is {{$age}}</h3>
</div>